import { users, type User, type InsertUser, type Category, type Organ, type Request, type Stats, categories, organs, requests, type Feedback } from "@shared/schema";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getCategories(): Promise<Category[]>;
  createCategory(category: Omit<Category, "id">): Promise<Category>;
  getOrgans(): Promise<(Organ & { category: Category })[]>;
  createOrgan(organ: Omit<Organ, "id" | "createdAt">): Promise<Organ>;
  getRequests(userId: number): Promise<(Request & { organ: Organ })[]>;
  createRequest(request: Omit<Request, "id" | "createdAt">): Promise<Request>;
  getStats(): Promise<Stats>;
  sessionStore: session.Store;
  createFeedback(feedback: Omit<Feedback, "id" | "createdAt">): Promise<Feedback>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getCategories(): Promise<Category[]> {
    return db.select().from(categories);
  }

  async createCategory(category: Omit<Category, "id">): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async getOrgans(): Promise<(Organ & { category: Category })[]> {
    const results = await db
      .select({
        organ: organs,
        category: categories,
      })
      .from(organs)
      .leftJoin(categories, eq(organs.categoryId, categories.id));

    return results.map(({ organ, category }) => ({
      ...organ,
      category: category!,
    }));
  }

  async createOrgan(organ: Omit<Organ, "id" | "createdAt">): Promise<Organ> {
    const [newOrgan] = await db.insert(organs).values(organ).returning();
    return newOrgan;
  }

  async getRequests(userId: number): Promise<(Request & { organ: Organ })[]> {
    const results = await db
      .select({
        request: requests,
        organ: organs,
      })
      .from(requests)
      .leftJoin(organs, eq(requests.organId, organs.id))
      .where(eq(requests.requesterId, userId));

    return results.map(({ request, organ }) => ({
      ...request,
      organ: organ!,
    }));
  }

  async createRequest(request: Omit<Request, "id" | "createdAt">): Promise<Request> {
    const [newRequest] = await db.insert(requests).values(request).returning();
    return newRequest;
  }

  async getStats(): Promise<Stats> {
    const [[{ userCount }], [{ requestCount }], [{ organCount }], [{ categoryCount }]] = await Promise.all([
      db.select({ userCount: sql<number>`count(*)` }).from(users),
      db.select({ requestCount: sql<number>`count(*)` }).from(requests),
      db.select({ organCount: sql<number>`count(*)` }).from(organs),
      db.select({ categoryCount: sql<number>`count(*)` }).from(categories),
    ]);

    return {
      centresEnrolled: Number(userCount) || 0,
      totalRequests: Number(requestCount) || 0,
      totalOrgans: Number(organCount) || 0,
      totalCategories: Number(categoryCount) || 0,
    };
  }
  async createFeedback(feedback: Omit<Feedback, "id" | "createdAt">): Promise<Feedback> {
    const [newFeedback] = await db.insert(feedback).values(feedback).returning();
    return newFeedback;
  }
}

export const storage = new DatabaseStorage();