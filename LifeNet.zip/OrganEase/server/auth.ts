import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

async function createDefaultAdminIfNeeded() {
  const admin = await storage.getUserByUsername("admin");
  if (!admin) {
    await storage.createUser({
      username: "admin",
      password: await hashPassword("admin"),
      hospitalName: "Admin Hospital",
      confirmPassword: "admin"
    });
  }
}

async function createDefaultCategoriesIfNeeded() {
  const categories = await storage.getCategories();
  if (categories.length === 0) {
    const defaultCategories = [
      {
        name: "Heart",
        description: "Cardiac tissue for transplant",
        expirationWindow: 4,
        imageUrl: "https://api.dicebear.com/7.x/shapes/svg?seed=heart",
        isActive: true,
      },
      {
        name: "Kidney",
        description: "Renal tissue for transplant",
        expirationWindow: 24,
        imageUrl: "https://api.dicebear.com/7.x/shapes/svg?seed=kidney",
        isActive: true,
      },
      {
        name: "Liver",
        description: "Hepatic tissue for transplant",
        expirationWindow: 12,
        imageUrl: "https://api.dicebear.com/7.x/shapes/svg?seed=liver",
        isActive: true,
      },
      {
        name: "Lungs",
        description: "Pulmonary tissue for transplant",
        expirationWindow: 6,
        imageUrl: "https://api.dicebear.com/7.x/shapes/svg?seed=lungs",
        isActive: true,
      },
      {
        name: "Cornea",
        description: "Eye tissue for transplant",
        expirationWindow: 14,
        imageUrl: "https://api.dicebear.com/7.x/shapes/svg?seed=cornea",
        isActive: true,
      }
    ];

    for (const category of defaultCategories) {
      await storage.createCategory(category);
    }
  }
}

async function createDefaultOrgansIfNeeded() {
  const organs = await storage.getOrgans();
  if (organs.length === 0) {
    const categories = await storage.getCategories();
    const defaultOrgans = categories.map((category) => ({
      categoryId: category.id,
      description: `Available ${category.name.toLowerCase()} for immediate transplant. Priority for local recipients.`,
      timeWindow: category.expirationWindow,
      imageUrls: ["https://api.dicebear.com/7.x/shapes/svg?seed=organ" + category.id],
      isAvailable: true,
      unitsAvailable: Math.floor(Math.random() * 3) + 1,
      pinCode: Math.random().toString(36).substring(2, 8).toUpperCase(),
    }));

    for (const organ of defaultOrgans) {
      await storage.createOrgan(organ);
    }
  }
}

export function setupAuth(app: Express) {
  // Initialize default data
  createDefaultAdminIfNeeded();
  createDefaultCategoriesIfNeeded();
  createDefaultOrgansIfNeeded();

  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET!,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
  };

  if (app.get("env") === "production") {
    app.set("trust proxy", 1);
  }

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      const user = await storage.getUserByUsername(username);
      if (!user || !(await comparePasswords(password, user.password))) {
        return done(null, false);
      } else {
        return done(null, user);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    const user = await storage.getUser(id);
    done(null, user);
  });

  app.post("/api/register", async (req, res, next) => {
    const existingUser = await storage.getUserByUsername(req.body.username);
    if (existingUser) {
      return res.status(400).send("Username already exists");
    }

    const user = await storage.createUser({
      ...req.body,
      password: await hashPassword(req.body.password),
    });

    req.login(user, (err) => {
      if (err) return next(err);
      res.status(201).json(user);
    });
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}