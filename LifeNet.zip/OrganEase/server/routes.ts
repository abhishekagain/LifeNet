import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import {
  insertCategorySchema,
  insertOrganSchema,
  insertRequestSchema,
  insertFeedbackSchema,
} from "@shared/schema";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Categories
  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  app.post("/api/categories", async (req, res) => {
    const parsed = insertCategorySchema.parse(req.body);
    const category = await storage.createCategory(parsed);
    res.status(201).json(category);
  });

  // Organs
  app.get("/api/organs", async (req, res) => {
    const organs = await storage.getOrgans();
    res.json(organs);
  });

  app.post("/api/organs", async (req, res) => {
    const parsed = insertOrganSchema.parse(req.body);
    const organ = await storage.createOrgan(parsed);
    res.status(201).json(organ);
  });

  // Requests
  app.get("/api/requests", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const requests = await storage.getRequests(req.user.id);
    res.json(requests);
  });

  app.post("/api/requests", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const parsed = insertRequestSchema.parse(req.body);
    const request = await storage.createRequest({
      ...parsed,
      requesterId: req.user.id,
    });
    res.status(201).json(request);
  });

  // Feedback
  app.post("/api/feedback", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const parsed = insertFeedbackSchema.parse(req.body);
    const feedback = await storage.createFeedback({
      ...parsed,
      userId: req.user.id,
      status: "pending",
    });
    res.status(201).json(feedback);
  });

  // Stats
  app.get("/api/stats", async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  const httpServer = createServer(app);
  return httpServer;
}