import { pgTable, text, serial, integer, boolean, timestamp, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (from auth blueprint)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  hospitalName: text("hospital_name").notNull(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  expirationWindow: integer("expiration_window").notNull(), // in hours
  imageUrl: text("image_url").notNull(),
  isActive: boolean("is_active").default(true),
});

export const organs = pgTable("organs", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").notNull().references(() => categories.id),
  timeWindow: integer("time_window").notNull(), // in hours
  description: text("description").notNull(),
  imageUrls: text("image_urls").array().notNull(),
  isAvailable: boolean("is_available").default(true),
  unitsAvailable: integer("units_available").notNull(),
  pinCode: text("pin_code").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const requests = pgTable("requests", {
  id: serial("id").primaryKey(),
  organId: integer("organ_id").notNull().references(() => organs.id),
  requesterId: integer("requester_id").notNull().references(() => users.id),
  status: text("status").notNull(), // pending, approved, rejected, completed
  createdAt: timestamp("created_at").defaultNow(),
});

// Schemas for data insertion
export const insertUserSchema = createInsertSchema(users).extend({
  confirmPassword: z.string(),
}).omit({ id: true });

export const insertCategorySchema = createInsertSchema(categories).omit({ id: true });
export const insertOrganSchema = createInsertSchema(organs).omit({ id: true, createdAt: true });
export const insertRequestSchema = createInsertSchema(requests).omit({ id: true, createdAt: true });

// Add these lines after the existing schemas
export const feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  type: text("type").notNull(), // feedback or support
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  status: text("status").default("pending"),
});

// Add to existing schemas section
export const insertFeedbackSchema = createInsertSchema(feedback).omit({ 
  id: true, 
  userId: true,
  createdAt: true,
  status: true 
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Organ = typeof organs.$inferSelect;
export type Request = typeof requests.$inferSelect;

// Add to existing types section
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Feedback = typeof feedback.$inferSelect;

// Stats type
export type Stats = {
  centresEnrolled: number;
  totalRequests: number;
  totalOrgans: number;
  totalCategories: number;
};