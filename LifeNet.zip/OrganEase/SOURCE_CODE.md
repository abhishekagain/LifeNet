# LifeNet - Source Code Reference

This document contains all the important source code files for the LifeNet project.

## Table of Contents
1. Database Schema
2. Core Components
3. Authentication System
4. API Routes
5. Utility Functions

## 1. Database Schema (`shared/schema.ts`)
```typescript
import { pgTable, serial, text, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password_hash: text("password_hash").notNull(),
  hospital_name: text("hospital_name").notNull(),
  email: text("email").unique(),
  created_at: timestamp("created_at").defaultNow()
});

// Organs Table
export const organs = pgTable("organs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  donor_id: integer("donor_id").references(() => users.id),
  status: text("status").notNull(),
  preservation_time: timestamp("preservation_time").notNull(),
  location: text("location"),
  created_at: timestamp("created_at").defaultNow()
});

// Requests Table
export const requests = pgTable("requests", {
  id: serial("id").primaryKey(),
  recipient_id: integer("recipient_id").references(() => users.id),
  organ_id: integer("organ_id").references(() => organs.id),
  status: text("status").notNull(),
  priority: integer("priority").notNull(),
  created_at: timestamp("created_at").defaultNow()
});

// Categories Table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  created_at: timestamp("created_at").defaultNow()
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).extend({
  password: z.string().min(8)
});

export const insertOrganSchema = createInsertSchema(organs);
export const insertRequestSchema = createInsertSchema(requests);
export const insertCategorySchema = createInsertSchema(categories);

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Organ = typeof organs.$inferSelect;
export type InsertOrgan = z.infer<typeof insertOrganSchema>;
export type Request = typeof requests.$inferSelect;
export type InsertRequest = z.infer<typeof insertRequestSchema>;
export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
```

## 2. Core Components (`client/src/components`)

### Sidebar Component (`sidebar.tsx`)
[Previous implementation remains here]

### Auth Provider (`auth-provider.tsx`)
```typescript
import { createContext, useContext, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { User } from "@shared/schema";

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    retry: false
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: { username: string; password: string }) => {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
      });
      if (!response.ok) throw new Error("Login failed");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/auth/logout", { method: "POST" });
      if (!response.ok) throw new Error("Logout failed");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user,
        login: loginMutation.mutate,
        logout: logoutMutation.mutate,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
```

## 3. Authentication System (`server/auth.ts`)
```typescript
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcrypt";
import { eq } from "drizzle-orm";
import { db } from "./db";
import { users } from "@shared/schema";

passport.use(
  new LocalStrategy(async (username, password, done) => {
    try {
      const user = await db.query.users.findFirst({
        where: eq(users.username, username),
      });

      if (!user) {
        return done(null, false, { message: "Incorrect username." });
      }

      const isValid = await bcrypt.compare(password, user.password_hash);
      if (!isValid) {
        return done(null, false, { message: "Incorrect password." });
      }

      return done(null, user);
    } catch (err) {
      return done(err);
    }
  })
);

passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await db.query.users.findFirst({
      where: eq(users.id, id),
    });
    done(null, user);
  } catch (err) {
    done(err);
  }
});
```

## 4. API Routes (`server/routes`)

### User Routes (`users.ts`)
```typescript
import express from "express";
import { db } from "../db";
import { users, insertUserSchema } from "@shared/schema";
import bcrypt from "bcrypt";

const router = express.Router();

router.post("/register", async (req, res) => {
  try {
    const data = insertUserSchema.parse(req.body);
    const hashedPassword = await bcrypt.hash(data.password, 10);
    
    const newUser = await db.insert(users).values({
      ...data,
      password_hash: hashedPassword,
    });

    res.status(201).json(newUser);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
```

### Organ Routes (`organs.ts`)
```typescript
import express from "express";
import { db } from "../db";
import { organs, insertOrganSchema } from "@shared/schema";
import { requireAuth } from "../middleware/auth";

const router = express.Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const allOrgans = await db.query.organs.findMany();
    res.json(allOrgans);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post("/", requireAuth, async (req, res) => {
  try {
    const data = insertOrganSchema.parse(req.body);
    const newOrgan = await db.insert(organs).values(data);
    res.status(201).json(newOrgan);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
```

## 5. Utility Functions (`client/src/lib/utils.ts`)
```typescript
import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const formatDate = (date: Date) => {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
};

export const calculatePreservationTime = (preservationTime: Date) => {
  const now = new Date();
  const diff = now.getTime() - preservationTime.getTime();
  const hours = Math.floor(diff / (1000 * 60 * 60));
  return hours;
};
```

This documentation contains the core source code of the LifeNet application. For the complete codebase, please refer to the project repository.

---
© 2024 RustedCoders. All Rights Reserved.
