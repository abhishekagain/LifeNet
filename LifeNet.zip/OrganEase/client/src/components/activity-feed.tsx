import { Activity, Heart, FileText, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const recentActivities = [
  {
    type: "organ_added",
    title: "New Organ Listed",
    description: "Heart available at City General Hospital",
    timestamp: "2 minutes ago",
    icon: Heart,
  },
  {
    type: "request_updated",
    title: "Request Updated",
    description: "Kidney transfer request approved",
    timestamp: "5 minutes ago",
    icon: FileText,
  },
  {
    type: "transfer_completed",
    title: "Transfer Completed",
    description: "Liver successfully transferred to Memorial Medical",
    timestamp: "10 minutes ago",
    icon: Activity,
  },
  {
    type: "organ_expiring",
    title: "Organ Expiring Soon",
    description: "Heart at Regional Medical - 2 hours remaining",
    timestamp: "15 minutes ago",
    icon: Clock,
  },
];

export function ActivityFeed() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentActivities.map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div
                key={index}
                className="flex items-start gap-3 p-3 rounded-lg hover:bg-accent/50 transition-colors"
              >
                <div className="mt-1">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{activity.title}</p>
                  <p className="text-sm text-muted-foreground">
                    {activity.description}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {activity.timestamp}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
