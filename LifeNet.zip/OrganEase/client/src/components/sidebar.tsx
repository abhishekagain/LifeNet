import { useState } from "react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  ListTree,
  Heart,
  FileText,
  LogOut,
  PlusCircle,
  Building2,
  Shield,
  AlertCircle,
  Phone,
  Sparkles,
  MessageSquare,
  HelpCircle,
  Activity,
  Info,
  Signal,
  Server,
  Shield as ShieldIcon,
  Clock,
  Zap,
  Video,
  BookOpen
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Card, CardContent } from "./ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Progress } from "@/components/ui/progress";

const routes = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/categories", label: "Categories", icon: ListTree },
  { href: "/organs", label: "Organs", icon: Heart },
  { href: "/requests", label: "Requests", icon: FileText },
  { href: "/centers", label: "Centers", icon: Building2 },
];

const upcomingFeatures = [
  "Enhanced organ tracking with GPS",
  "Mobile app for updates",
  "AI-powered organ matching",
  "Blockchain tracking system",
  "Cross-border organ sharing",
  "Advanced analytics dashboard",
  "Real-time notification system",
  "Virtual consultation platform",
];

const emergencyContacts = [
  { name: "Emergency Response Team", number: "1-800-ORGAN", available: "24/7", priority: "High" },
  { name: "Transport Coordinator", number: "1-888-TRANS", available: "24/7", priority: "High" },
  { name: "Medical Support", number: "1-877-MED", available: "24/7", priority: "Medium" },
  { name: "Crisis Hotline", number: "1-866-HELP", available: "24/7", priority: "High" },
  { name: "Organ Preservation Unit", number: "1-855-PRES", available: "24/7", priority: "High" },
  { name: "Regional Coordinator", number: "1-844-REG", available: "9am-5pm", priority: "Medium" },
  { name: "Quality Assurance Team", number: "1-833-QA", available: "24/7", priority: "Medium" },
  { name: "Documentation Support", number: "1-822-DOC", available: "8am-8pm", priority: "Low" },
  { name: "Technical Support", number: "1-811-TECH", available: "24/7", priority: "Medium" },
  { name: "Administrative Office", number: "1-800-ADMIN", available: "9am-5pm", priority: "Low" }
];

const aboutUsContent = [
  {
    title: "Our Mission",
    description: "To revolutionize organ donation and transplantation through innovative digital solutions.",
    icon: Heart
  },
  {
    title: "Our Impact",
    description: "Successfully facilitated over 1000+ organ transfers across medical centers.",
    icon: Activity
  },
  {
    title: "Our Technology",
    description: "Utilizing cutting-edge blockchain and AI for secure, efficient organ matching.",
    icon: Sparkles
  }
];

const systemStatus = [
  {
    name: "Server Response",
    status: "Operational",
    metric: "23ms",
    icon: Server,
    color: "text-green-500"
  },
  {
    name: "Network Speed",
    status: "Optimal",
    metric: "99.9%",
    icon: Signal,
    color: "text-green-500"
  },
  {
    name: "Security",
    status: "Active",
    metric: "Protected",
    icon: ShieldIcon,
    color: "text-green-500"
  },
  {
    name: "Last Update",
    status: "Recent",
    metric: "2 min ago",
    icon: Clock,
    color: "text-blue-500"
  }
];

export function Sidebar() {
  const { user, logoutMutation } = useAuth();
  const [quickStats] = useState({
    availableOrgans: 15,
    activeRequests: 8,
    matchRate: 85,
  });

  return (
    <div className="w-64 bg-card border-r flex flex-col h-screen">
      {/* Logo */}
      <div className="p-3 border-b shrink-0">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Heart className="h-6 w-6 text-primary" />
          LifeNet
        </h1>
      </div>

      {/* User Details */}
      <div className="p-3 border-b shrink-0">
        <div className="flex items-center gap-3 mb-3">
          <Avatar>
            <AvatarFallback className="bg-primary/10">
              {user?.hospitalName?.charAt(0) || 'H'}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user?.hospitalName}</p>
            <p className="text-xs text-muted-foreground truncate">
              @{user?.username}
            </p>
          </div>
        </div>
        <Card className="bg-primary/5">
          <CardContent className="p-3 space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <Building2 className="h-4 w-4 text-primary" />
              <span className="text-muted-foreground">Medical Center</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Shield className="h-4 w-4 text-primary" />
              <span className="text-muted-foreground">Verified Institution</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Activity className="h-4 w-4 text-primary" />
              <span className="text-muted-foreground">Active Organs: 15</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main content with hidden scrollbar */}
      <div className="flex-1 overflow-y-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
        {/* Navigation */}
        <nav className="p-2 space-y-1 border-b">
          {routes.map((route) => (
            <SidebarLink key={route.href} {...route} />
          ))}
        </nav>

        {/* Quick Dashboard - Always Expanded */}
        <div className="p-3 border-b">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-medium text-primary">
              <Zap className="h-4 w-4" />
              Quick Dashboard
            </div>
            <div className="space-y-3">
              {/* Available Organs */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-medium">Available Organs</span>
                  <span className="text-xs text-primary">{quickStats.availableOrgans}</span>
                </div>
                <Progress value={60} className="h-1" />
              </div>

              {/* Active Requests */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-medium">Active Requests</span>
                  <span className="text-xs text-primary">{quickStats.activeRequests}</span>
                </div>
                <Progress value={40} className="h-1" />
              </div>

              {/* Match Rate */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-medium">Match Rate</span>
                  <span className="text-xs text-primary">{quickStats.matchRate}%</span>
                </div>
                <Progress value={quickStats.matchRate} className="h-1" />
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="w-full">
                  <PlusCircle className="h-3 w-3 mr-1" />
                  Add Organ
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <FileText className="h-3 w-3 mr-1" />
                  Request
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Emergency Contacts - Collapsible and Initially Collapsed */}
        <div className="p-3 border-b">
          <Collapsible defaultOpen={false}>
            <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium text-destructive hover:text-destructive/90 mb-2">
              <AlertCircle className="h-4 w-4" />
              Emergency Contacts
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-2">
              <div className="space-y-2">
                {emergencyContacts.map((contact, index) => (
                  <div
                    key={index}
                    className={cn(
                      "flex items-start gap-2 p-2 rounded-lg hover:bg-accent/50 transition-colors",
                      contact.priority === "High" && "border-l-2 border-destructive"
                    )}
                  >
                    <Phone className="h-4 w-4 text-primary mt-1" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{contact.name}</p>
                      <p className="text-xs text-muted-foreground">{contact.number}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-primary">{contact.available}</span>
                        {contact.priority === "High" && (
                          <span className="text-xs text-destructive">Priority</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>

        {/* Support & Help Section - Collapsible and Initially Collapsed */}
        <div className="p-3 border-b">
          <Collapsible defaultOpen={false}>
            <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground mb-2">
              <HelpCircle className="h-4 w-4 text-primary" />
              Support & Help
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-2">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-muted-foreground hover:text-foreground"
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                Live Chat Support
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-muted-foreground hover:text-foreground"
              >
                <FileText className="mr-2 h-4 w-4" />
                Documentation
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-muted-foreground hover:text-foreground"
              >
                <AlertCircle className="mr-2 h-4 w-4" />
                FAQs
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-muted-foreground hover:text-foreground"
              >
                <Video className="mr-2 h-4 w-4" />
                Video Tutorials
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-muted-foreground hover:text-foreground"
              >
                <BookOpen className="mr-2 h-4 w-4" />
                User Guide
              </Button>
            </CollapsibleContent>
          </Collapsible>
        </div>

        {/* System Status - Collapsible and Initially Collapsed */}
        <div className="p-3 border-b">
          <Collapsible defaultOpen={false}>
            <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground mb-2">
              <Activity className="h-4 w-4 text-primary" />
              System Status
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-2">
              {systemStatus.map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.name}
                    className="flex items-center justify-between p-2 rounded-lg bg-accent/50"
                  >
                    <div className="flex items-center gap-2">
                      <Icon className={`h-4 w-4 ${item.color}`} />
                      <div>
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.status}</p>
                      </div>
                    </div>
                    <span className={`text-xs font-medium ${item.color}`}>
                      {item.metric}
                    </span>
                  </div>
                );
              })}
            </CollapsibleContent>
          </Collapsible>
        </div>

        {/* About Us Section - Collapsible and Initially Collapsed */}
        <div className="p-3 border-b">
          <Collapsible defaultOpen={false}>
            <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground mb-2">
              <Info className="h-4 w-4 text-primary" />
              About Us
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-3">
              {aboutUsContent.map((content) => {
                const Icon = content.icon;
                return (
                  <div
                    key={content.title}
                    className="p-3 rounded-lg bg-accent/50 space-y-2"
                  >
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4 text-primary" />
                      <h4 className="font-medium text-sm">{content.title}</h4>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {content.description}
                    </p>
                  </div>
                );
              })}
            </CollapsibleContent>
          </Collapsible>
        </div>
      </div>

      {/* Logout and Credits */}
      <div className="p-3 border-t mt-auto shrink-0">
        <Button
          variant="ghost"
          className="w-full justify-start text-muted-foreground hover:text-foreground"
          onClick={() => logoutMutation.mutate()}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
        <p className="text-xs text-primary font-medium text-center mt-2">
          Developed by RustedCoders
        </p>
      </div>
    </div>
  );
}

function SidebarLink({
  href,
  label,
  icon: Icon,
}: {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <Link href={href}>
      {({ isActive }: { isActive: boolean }) => (
        <a
          className={cn(
            "flex items-center gap-3 px-4 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors",
            isActive && "bg-accent text-foreground"
          )}
        >
          <Icon className="h-5 w-5" />
          {label}
        </a>
      )}
    </Link>
  );
}