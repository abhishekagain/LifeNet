import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { StatCard } from "@/components/stat-card";
import { Button } from "@/components/ui/button";
import {
  Activity,
  Building2,
  FileText,
  Heart,
  Loader2,
  PlusCircle,
  Bell,
  Clock,
  Search,
  AlertCircle,
  ShieldCheck,
  Users,
  Zap,
  Database,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import { OrganForm } from "@/components/organ-form";
import { RequestForm } from "@/components/request-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FeatureSlider } from "@/components/feature-slider";
import { ActivityFeed } from "@/components/activity-feed";

type Stats = {
  centresEnrolled: number;
  totalRequests: number;
  totalOrgans: number;
  totalCategories: number;
};

const features = [
  {
    icon: Clock,
    title: "Real-time Updates",
    description: "Get instant notifications about organ availability and status changes",
  },
  {
    icon: Search,
    title: "Smart Matching",
    description: "Advanced algorithms to match organs with compatible recipients",
  },
  {
    icon: AlertCircle,
    title: "Priority System",
    description: "Emergency requests are automatically prioritized",
  },
  {
    icon: Bell,
    title: "Alert System",
    description: "Immediate notifications for time-sensitive organ matches",
  },
  {
    icon: ShieldCheck,
    title: "Secure Transfer",
    description: "End-to-end encrypted organ transfer documentation",
  },
  {
    icon: Users,
    title: "Multi-Center Network",
    description: "Connect with multiple transplant centers seamlessly",
  },
  {
    icon: Zap,
    title: "Quick Response",
    description: "Rapid organ matching and allocation system",
  },
  {
    icon: Database,
    title: "Data Analytics",
    description: "Comprehensive reporting and analytics dashboard",
  },
];

const enrolledHospitals = [
  "City General Hospital",
  "Memorial Medical Center",
  "St. Mary's Hospital",
  "Regional Medical Center",
  "University Hospital"
];

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  const { user } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome, {user?.hospitalName}</h1>
          <p className="text-muted-foreground">
            Manage your organ transfers and requests from your dashboard
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="mb-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Quick Links</h2>
                <div className="flex gap-4">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add New Organ
                      </Button>
                    </DialogTrigger>
                    <OrganForm />
                  </Dialog>

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="secondary">
                        <FileText className="mr-2 h-4 w-4" />
                        New Request
                      </Button>
                    </DialogTrigger>
                    <RequestForm />
                  </Dialog>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Link href="/organs">
                  <a className="block p-4 rounded-lg border bg-card hover:bg-accent transition-colors">
                    <div className="flex items-center gap-2">
                      <Heart className="h-5 w-5 text-primary" />
                      <span className="font-medium">View All Organs</span>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Browse and manage available organs
                    </p>
                  </a>
                </Link>
                <Link href="/requests">
                  <a className="block p-4 rounded-lg border bg-card hover:bg-accent transition-colors">
                    <div className="flex items-center gap-2">
                      <FileText className="h-5 w-5 text-primary" />
                      <span className="font-medium">Manage Requests</span>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Track and update transfer requests
                    </p>
                  </a>
                </Link>
                <Link href="/centers">
                  <a className="block p-4 rounded-lg border bg-card hover:bg-accent transition-colors">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-primary" />
                      <span className="font-medium">View All Centers</span>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      View all participating centers
                    </p>
                  </a>
                </Link>
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Statistics Overview</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard
                  title="Centres Enrolled"
                  value={stats?.centresEnrolled || 0}
                  description="Total medical centers in network"
                  icon={Building2}
                />
                <StatCard
                  title="Active Requests"
                  value={stats?.totalRequests || 0}
                  description="Pending organ transfer requests"
                  icon={FileText}
                />
                <StatCard
                  title="Available Organs"
                  value={stats?.totalOrgans || 0}
                  description="Currently available for transfer"
                  icon={Heart}
                />
                <StatCard
                  title="Organ Categories"
                  value={stats?.totalCategories || 0}
                  description="Types of organs managed"
                  icon={Activity}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
              <div className="lg:col-span-2">
                <ActivityFeed />
              </div>
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold flex items-center gap-2">
                      <Clock className="h-5 w-5 text-primary" />
                      Upcoming Deadlines
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Heart Transfer</p>
                          <p className="text-sm text-muted-foreground">City General Hospital</p>
                        </div>
                        <div className="text-sm text-destructive">2 hours left</div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Kidney Match</p>
                          <p className="text-sm text-muted-foreground">St. Mary's Hospital</p>
                        </div>
                        <div className="text-sm text-primary">4 hours left</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="features">
            <Card>
              <CardHeader>
                <CardTitle>Platform Features</CardTitle>
              </CardHeader>
              <CardContent>
                <FeatureSlider features={features} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}