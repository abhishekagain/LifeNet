import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Organ, Category } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { PlusCircle, Loader2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { OrganForm } from "@/components/organ-form";

type OrganWithCategory = Organ & { category: Category };

export default function Organs() {
  const { data: organs, isLoading } = useQuery<OrganWithCategory[]>({
    queryKey: ["/api/organs"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Organs</h1>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Organ
              </Button>
            </DialogTrigger>
            <OrganForm />
          </Dialog>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Category</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Time Window</TableHead>
                <TableHead>Units</TableHead>
                <TableHead>PIN Code</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {organs?.map((organ) => (
                <TableRow key={organ.id}>
                  <TableCell className="font-medium">
                    {organ.category.name}
                  </TableCell>
                  <TableCell>{organ.description}</TableCell>
                  <TableCell>{organ.timeWindow} hours</TableCell>
                  <TableCell>{organ.unitsAvailable}</TableCell>
                  <TableCell>
                    <code className="bg-muted px-2 py-1 rounded">
                      {organ.pinCode}
                    </code>
                  </TableCell>
                  <TableCell>
                    <Badge variant={organ.isAvailable ? "default" : "secondary"}>
                      {organ.isAvailable ? "Available" : "Unavailable"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
}
