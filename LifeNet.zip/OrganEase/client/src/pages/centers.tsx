import { Building2, Activity, Heart, Phone, Search, Filter } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
//import { ThemeSwitcher } from "@/components/theme-switcher"; //removed import

const enrolledHospitals = [
  {
    name: "City General Hospital",
    activeOrgans: 3,
    successRate: "98%",
    responseTime: "15 min",
    status: "Active Member",
    phoneNumber: "1-800-CITY-GEN",
    location: "Downtown Medical District",
    specialties: ["Heart", "Kidney", "Liver"],
    availability: "24/7",
    lastActive: "2 minutes ago"
  },
  {
    name: "Memorial Medical Center",
    activeOrgans: 5,
    successRate: "96%",
    responseTime: "12 min",
    status: "Active Member",
    phoneNumber: "1-800-MEM-MED",
    location: "Westside Healthcare Complex",
    specialties: ["Lungs", "Heart", "Cornea"],
    availability: "24/7",
    lastActive: "5 minutes ago"
  },
  {
    name: "St. Mary's Hospital",
    activeOrgans: 4,
    successRate: "97%",
    responseTime: "18 min",
    status: "Active Member",
    phoneNumber: "1-800-ST-MARY",
    location: "North Medical Campus",
    specialties: ["Kidney", "Liver", "Pancreas"],
    availability: "24/7",
    lastActive: "10 minutes ago"
  },
  {
    name: "Regional Medical Center",
    activeOrgans: 6,
    successRate: "95%",
    responseTime: "14 min",
    status: "Active Member",
    phoneNumber: "1-800-REG-MED",
    location: "East Healthcare District",
    specialties: ["Heart", "Lungs", "Liver"],
    availability: "24/7",
    lastActive: "15 minutes ago"
  },
  {
    name: "University Hospital",
    activeOrgans: 7,
    successRate: "99%",
    responseTime: "10 min",
    status: "Active Member",
    phoneNumber: "1-800-UNI-HOSP",
    location: "South Medical Research Park",
    specialties: ["All Organs"],
    availability: "24/7",
    lastActive: "1 minute ago"
  },
];

export default function Centers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterBy, setFilterBy] = useState("all");

  const filteredHospitals = enrolledHospitals.filter(hospital => {
    const matchesSearch = hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hospital.specialties.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));

    if (filterBy === "all") return matchesSearch;
    if (filterBy === "high_success") return matchesSearch && parseInt(hospital.successRate) > 96;
    if (filterBy === "quick_response") return matchesSearch && parseInt(hospital.responseTime) < 15;
    return matchesSearch;
  });

  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Centers Enrolled</h1>
          <p className="text-muted-foreground">
            Detailed overview of all participating medical centers in our network
          </p>
        </div>

        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by hospital name or specialty..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterBy} onValueChange={setFilterBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Centers</SelectItem>
              <SelectItem value="high_success">High Success Rate</SelectItem>
              <SelectItem value="quick_response">Quick Response Time</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredHospitals.map((hospital) => (
            <Card key={hospital.name} className="bg-card hover:bg-accent/50 transition-colors">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-3">
                  <Building2 className="h-5 w-5 text-primary" />
                  <h3 className="font-medium">{hospital.name}</h3>
                </div>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Active Organs:</span>
                    <span className="font-medium">{hospital.activeOrgans}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Success Rate:</span>
                    <span className="font-medium">{hospital.successRate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Response Time:</span>
                    <span className="font-medium">{hospital.responseTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Location:</span>
                    <span className="font-medium">{hospital.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Active:</span>
                    <span className="font-medium">{hospital.lastActive}</span>
                  </div>
                  <div className="mt-2">
                    <span className="font-medium">Specialties:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {hospital.specialties.map((specialty) => (
                        <span
                          key={specialty}
                          className="inline-flex items-center px-2 py-1 rounded-full bg-primary/10 text-primary text-xs"
                        >
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="mt-3">
                    <Button
                      variant="outline"
                      className="w-full flex items-center gap-2"
                      onClick={() => window.location.href = `tel:${hospital.phoneNumber}`}
                    >
                      <Phone className="h-4 w-4" />
                      Contact ({hospital.phoneNumber})
                    </Button>
                  </div>
                  <div className="mt-3 text-xs">
                    <span className="inline-flex items-center px-2 py-1 rounded-full bg-primary/10 text-primary">
                      {hospital.status}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}